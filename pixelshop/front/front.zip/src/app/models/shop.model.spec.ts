import { Shop.Model } from './shop.model';

describe('Shop.Model', () => {
  it('should create an instance', () => {
    expect(new Shop.Model()).toBeTruthy();
  });
});

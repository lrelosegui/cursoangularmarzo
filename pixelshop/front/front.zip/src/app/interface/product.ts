export interface Product {
    title?: string;
    desc?: string;
    price?: number;
    picture?: string;
}
